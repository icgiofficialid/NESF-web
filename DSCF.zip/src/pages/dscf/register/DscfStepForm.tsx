// ================================================================
// DscfStepForm.tsx — Step 3: Form Pendaftaran DSCF 2026
// Path: src/pages/nesf/register/DscfStepForm.tsx
//
// Disesuaikan dengan Juknis DSCF 2026:
//   DESF → tim (maks 3), proyek sains, makalah, standing banner
//   DMO  → individu, laptop pribadi, olimpiade matematika
//   DCC  → Tari (solo/grup, maks 5 menit) / MHQ (maks 10 orang)
// ================================================================
import { useState } from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Field, TextInput, TextArea, SelectInput, SectionTitle,
  type DscfSubEvent, type FormData,
  DSCF_REQUIRED_FIELDS,
  DESF_PROJECT_CATEGORIES,
  DMO_DIVISIONS,
  DCC_CATEGORIES,
  DSCF_SUB_LABELS,
  DSCF_PRICE_MAP,
  submitToDscfSheet,
} from "./dscfRegisterConfig";

interface Props {
  subEvent: DscfSubEvent;
  onBack: () => void;
  onSuccess: (subEvent: DscfSubEvent, form: FormData) => void;
}

// ── Overlays ──────────────────────────────────────────────────────
const SpinnerOverlay = () => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
    <div
      className="w-14 h-14 border-4 border-t-transparent rounded-full animate-spin"
      style={{ borderColor: "hsl(var(--primary) / 0.3)", borderTopColor: "hsl(var(--primary))" }}
    />
  </div>
);

const SuccessOverlay = ({ onDone }: { onDone: () => void }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
    <div className="bg-card border border-border rounded-2xl p-10 flex flex-col items-center gap-4 text-center shadow-xl max-w-sm mx-4">
      <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center">
        <Check className="text-emerald-500" size={32} />
      </div>
      <h2 className="text-xl font-bold text-foreground font-display">Pendaftaran Berhasil!</h2>
      <p className="text-sm text-muted-foreground leading-6">
        LoA akan dikirim ke email ketua tim dalam 3 hari kerja setelah pembayaran terverifikasi. Terima kasih telah mendaftar DSCF 2026!
      </p>
      <Button size="lg" className="w-full mt-2" onClick={onDone}>
        Kembali ke Beranda
      </Button>
    </div>
  </div>
);

// ── Form DESF ─────────────────────────────────────────────────────
const DesfForm = ({ f, set }: { f: (k: string) => string; set: (k: string) => (v: string) => void }) => (
  <>
    {/* Data Tim */}
    <div>
      <SectionTitle title="Data Tim" />
      <div className="grid gap-4">
        <Field
          label="Nama Ketua & Anggota Tim"
          required
          note="Pisahkan dengan tanda / · Maks. 3 anggota per tim. Cth: Budi Santoso / Rina Dewi / Ahmad Fauzi"
        >
          <TextArea
            placeholder="Ketua / Anggota1 / Anggota2"
            value={f("NAMA_LENGKAP")} onChange={set("NAMA_LENGKAP")} maxLength={300}
          />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="WhatsApp Ketua Tim" required note="Sertakan kode negara. Cth: +62 817 xxxx">
            <TextInput placeholder="+62 …" value={f("LEADER_WHATSAPP")} onChange={set("LEADER_WHATSAPP")} type="tel" />
          </Field>
          <Field label="Email Ketua Tim" required note="LoA akan dikirim ke email ini.">
            <TextInput placeholder="email@example.com" value={f("LEADER_EMAIL")} onChange={set("LEADER_EMAIL")} type="email" />
          </Field>
        </div>
        <Field label="Instagram / Media Sosial Tim">
          <TextInput placeholder="@username" value={f("SOCIAL_MEDIA")} onChange={set("SOCIAL_MEDIA")} />
        </Field>
      </div>
    </div>

    {/* Data Sekolah */}
    <div>
      <SectionTitle title="Data Sekolah / Institusi" />
      <div className="grid gap-4">
        <Field label="Nama Sekolah / Institusi" required>
          <TextInput placeholder="Cth. SMP Negeri 1 Depok" value={f("NAMA_SEKOLAH")} onChange={set("NAMA_SEKOLAH")} />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Jenjang" required>
            <SelectInput
              placeholder="-- Pilih Jenjang --"
              value={f("GRADE")} onChange={set("GRADE")}
              options={["SD (Sekolah Dasar)", "SMP (Sekolah Menengah Pertama)", "SMA/SMK (Sekolah Menengah Atas)"]}
            />
          </Field>
          <Field label="NISN / NIM Ketua Tim">
            <TextInput placeholder="Nomor identitas siswa" value={f("NISN_NIM")} onChange={set("NISN_NIM")} />
          </Field>
        </div>
        <Field label="Provinsi / Kota" required>
          <TextInput placeholder="Cth. Jawa Barat" value={f("PROVINCE")} onChange={set("PROVINCE")} />
        </Field>
      </div>
    </div>

    {/* Data Pembimbing */}
    <div>
      <SectionTitle title="Data Guru Pembimbing" />
      <div className="grid gap-4">
        <Field label="Nama Guru Pembimbing" required>
          <TextInput placeholder="Nama lengkap pembimbing" value={f("NAME_SUPERVISOR")} onChange={set("NAME_SUPERVISOR")} />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="WhatsApp Pembimbing" required note="Sertakan kode negara.">
            <TextInput placeholder="+62 …" value={f("WHATSAPP_NUMBER_SUPERVISOR")} onChange={set("WHATSAPP_NUMBER_SUPERVISOR")} type="tel" />
          </Field>
          <Field label="Email Pembimbing" required>
            <TextInput placeholder="guru@sekolah.sch.id" value={f("EMAIL_TEACHER_SUPERVISOR")} onChange={set("EMAIL_TEACHER_SUPERVISOR")} type="email" />
          </Field>
        </div>
      </div>
    </div>

    {/* Data Proyek DESF */}
    <div>
      <SectionTitle title="Data Proyek DESF" />
      <div className="grid gap-4">
        <Field label="Kategori Bidang Proyek" required>
          <SelectInput
            placeholder="-- Pilih Kategori Bidang --"
            value={f("CATEGORIES")} onChange={set("CATEGORIES")}
            options={DESF_PROJECT_CATEGORIES}
          />
        </Field>
        <Field
          label="Judul Proyek / Penelitian"
          required
          note="Tidak dapat diubah setelah pengiriman formulir."
        >
          <TextInput placeholder="Masukkan judul proyek Anda" value={f("PROJECT_TITLE")} onChange={set("PROJECT_TITLE")} />
        </Field>
        <Field
          label="Abstrak / Ringkasan Proyek"
          note="Latar belakang, metode, dan hasil proyek secara singkat (maks. 300 kata)."
        >
          <TextArea
            placeholder="Deskripsikan proyek Anda…"
            value={f("PROJECT_ABSTRACT")} onChange={set("PROJECT_ABSTRACT")} maxLength={1500}
          />
        </Field>
        <Field
          label="Link Makalah & Dokumen Proyek (Google Drive)"
          note="Upload makalah lengkap (PDF/Word, maks. 12 halaman) ke Google Drive. Template makalah: https://bit.ly/FORMAT-FULL-PAPER"
        >
          <TextInput placeholder="https://drive.google.com/…" value={f("DRIVE_LINK")} onChange={set("DRIVE_LINK")} />
        </Field>

        {/* Partisipasi sebelumnya */}
        <Field
          label="Apakah judul proyek ini pernah diikutkan kompetisi sebelumnya?"
          required
        >
          <SelectInput
            placeholder="-- Pilih --"
            value={f("YES_NO")} onChange={set("YES_NO")}
            options={["Tidak", "Ya"]}
          />
        </Field>
        {f("YES_NO") === "Ya" && (
          <Field
            label="Nama Kompetisi Sebelumnya"
            note="Tuliskan nama event/kompetisi yang pernah diikuti dengan judul yang sama."
          >
            <TextInput
              placeholder="Cth. IESF 2025, BIESF 2025…"
              value={f("JUDUL_PERNAH_BERPARTISIPASI")} onChange={set("JUDUL_PERNAH_BERPARTISIPASI")}
            />
          </Field>
        )}
      </div>
    </div>
  </>
);

// ── Form DMO ──────────────────────────────────────────────────────
const DmoForm = ({ f, set }: { f: (k: string) => string; set: (k: string) => (v: string) => void }) => (
  <>
    {/* Data Peserta */}
    <div>
      <SectionTitle title="Data Peserta (Individu)" />
      <div className="grid gap-4">
        <Field label="Nama Lengkap Peserta" required note="Sesuai identitas resmi (kartu pelajar / KTP).">
          <TextInput placeholder="Nama lengkap" value={f("NAMA_LENGKAP")} onChange={set("NAMA_LENGKAP")} />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="WhatsApp Peserta / Orang Tua" required note="Sertakan kode negara. Cth: +62 817 xxxx">
            <TextInput placeholder="+62 …" value={f("LEADER_WHATSAPP")} onChange={set("LEADER_WHATSAPP")} type="tel" />
          </Field>
          <Field label="Email Peserta / Orang Tua" required note="LoA akan dikirim ke email ini.">
            <TextInput placeholder="email@example.com" value={f("LEADER_EMAIL")} onChange={set("LEADER_EMAIL")} type="email" />
          </Field>
        </div>
        <Field label="Instagram / Media Sosial">
          <TextInput placeholder="@username" value={f("SOCIAL_MEDIA")} onChange={set("SOCIAL_MEDIA")} />
        </Field>
      </div>
    </div>

    {/* Data Sekolah */}
    <div>
      <SectionTitle title="Data Sekolah" />
      <div className="grid gap-4">
        <Field label="Nama Sekolah" required>
          <TextInput placeholder="Cth. SDN 1 Depok" value={f("NAMA_SEKOLAH")} onChange={set("NAMA_SEKOLAH")} />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Jenjang / Kelas" required note="Pilih sesuai kelas saat ini.">
            <SelectInput
              placeholder="-- Pilih Jenjang/Kelas --"
              value={f("GRADE")} onChange={set("GRADE")}
              options={DMO_DIVISIONS}
            />
          </Field>
          <Field label="NISN">
            <TextInput placeholder="Nomor induk siswa" value={f("NISN_NIM")} onChange={set("NISN_NIM")} />
          </Field>
        </div>
        <Field label="Provinsi / Kota" required>
          <TextInput placeholder="Cth. Jawa Barat" value={f("PROVINCE")} onChange={set("PROVINCE")} />
        </Field>
      </div>
    </div>

    {/* Data Pembimbing */}
    <div>
      <SectionTitle title="Data Guru Pembimbing" />
      <div className="grid gap-4">
        <Field label="Nama Guru Pembimbing" required>
          <TextInput placeholder="Nama lengkap pembimbing" value={f("NAME_SUPERVISOR")} onChange={set("NAME_SUPERVISOR")} />
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="WhatsApp Pembimbing" required>
            <TextInput placeholder="+62 …" value={f("WHATSAPP_NUMBER_SUPERVISOR")} onChange={set("WHATSAPP_NUMBER_SUPERVISOR")} type="tel" />
          </Field>
          <Field label="Email Pembimbing" required>
            <TextInput placeholder="guru@sekolah.sch.id" value={f("EMAIL_TEACHER_SUPERVISOR")} onChange={set("EMAIL_TEACHER_SUPERVISOR")} type="email" />
          </Field>
        </div>
      </div>
    </div>

    {/* Info DMO */}
    <div>
      <SectionTitle title="Informasi Olimpiade" />
      <div className="grid gap-4">
        <Field label="Bidang Olimpiade" required note="DMO adalah olimpiade matematika individu satu babak (single round).">
          <Input value="Depok Math Olympiad — Matematika" disabled className="rounded-lg bg-muted/20 text-sm" />
        </Field>
        <div className="rounded-xl p-4 text-xs text-muted-foreground bg-amber-500/5 border border-amber-500/20 leading-6">
          <p className="font-semibold text-foreground mb-1">📋 Ketentuan Teknis DMO</p>
          <ul className="space-y-0.5 list-disc list-inside">
            <li>Peserta wajib membawa <strong className="text-foreground">laptop pribadi</strong> dan alat tulis.</li>
            <li>Wi-Fi akan disediakan oleh panitia.</li>
            <li>Penilaian: setiap soal pilihan ganda bernilai <strong className="text-foreground">1 poin</strong>.</li>
            <li>Medali Emas: KKM &gt; 80 · Perak: 70–79 · Perunggu: &lt; 69.</li>
            <li>Keterlambatan hadir akan mengurangi waktu pengerjaan.</li>
          </ul>
        </div>
      </div>
    </div>
  </>
);

// ── Form DCC ──────────────────────────────────────────────────────
const DccForm = ({ f, set }: { f: (k: string) => string; set: (k: string) => (v: string) => void }) => {
  const isMhq = f("CATEGORIES") === "DCC — MHQ (Marawis, Hadroh & Qasidah)";
  const isTari = f("CATEGORIES").includes("Tari");

  return (
    <>
      {/* Kategori DCC — pilih dulu, karena form dinamis */}
      <div>
        <SectionTitle title="Kategori Kompetisi" />
        <div className="grid gap-4">
          <Field label="Kategori DCC" required note="Pilih kategori terlebih dahulu sebelum mengisi data tim.">
            <SelectInput
              placeholder="-- Pilih Kategori DCC --"
              value={f("CATEGORIES")} onChange={set("CATEGORIES")}
              options={DCC_CATEGORIES}
            />
          </Field>

          {/* Info per kategori */}
          {isTari && (
            <div className="rounded-xl p-4 text-xs text-muted-foreground bg-primary/5 border border-primary/20 leading-6">
              <p className="font-semibold text-foreground mb-1">💃 Ketentuan Lomba Tari</p>
              <ul className="space-y-0.5 list-disc list-inside">
                <li>Durasi penampilan <strong className="text-foreground">maksimal 5 menit</strong>.</li>
                <li>Urutan penampilan ditentukan panitia dan <strong className="text-foreground">tidak dapat diubah</strong>.</li>
                <li>File musik (MP3/WAV) wajib dikirim <strong className="text-foreground">H-14 sebelum acara</strong>.</li>
                <li>Peserta wajib membawa file musik cadangan pada hari acara.</li>
              </ul>
            </div>
          )}
          {isMhq && (
            <div className="rounded-xl p-4 text-xs text-muted-foreground bg-primary/5 border border-primary/20 leading-6">
              <p className="font-semibold text-foreground mb-1">🥁 Ketentuan MHQ (Marawis, Hadroh & Qasidah)</p>
              <ul className="space-y-0.5 list-disc list-inside">
                <li>Jumlah peserta <strong className="text-foreground">maksimal 10 orang/tim</strong>. Terbuka untuk umum.</li>
                <li>Membawakan <strong className="text-foreground">1 sholawat</strong> + <strong className="text-foreground">1 lagu bebas bernuansa islami</strong>.</li>
                <li>Waktu penampilan <strong className="text-foreground">maksimal 5 menit</strong>.</li>
                <li>Peserta membawa <strong className="text-foreground">peralatan musik sendiri</strong>. Peralatan elektronik <strong className="text-foreground">TIDAK diperkenankan</strong>.</li>
                <li>Seluruh peserta wajib hadir <strong className="text-foreground">30 menit sebelum acara</strong>.</li>
                <li>Urutan tampil ditentukan berdasarkan urutan registrasi ulang di tempat.</li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Data Tim */}
      <div>
        <SectionTitle title="Data Tim / Peserta" />
        <div className="grid gap-4">
          <Field
            label="Nama Ketua / Seluruh Anggota Tim"
            required
            note={
              isMhq
                ? "Daftar nama semua anggota (maks. 10 orang). Pisahkan dengan / ·  Cth: Ketua / Anggota1 / Anggota2"
                : "Solo: nama peserta. Grup: Ketua / Anggota1 / Anggota2 …"
            }
          >
            <TextArea
              placeholder="Nama Ketua / Anggota1 / Anggota2 / …"
              value={f("NAMA_LENGKAP")} onChange={set("NAMA_LENGKAP")} maxLength={500}
            />
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="WhatsApp Ketua Tim" required note="Sertakan kode negara.">
              <TextInput placeholder="+62 …" value={f("LEADER_WHATSAPP")} onChange={set("LEADER_WHATSAPP")} type="tel" />
            </Field>
            <Field label="Email Ketua Tim" required note="LoA akan dikirim ke email ini.">
              <TextInput placeholder="email@example.com" value={f("LEADER_EMAIL")} onChange={set("LEADER_EMAIL")} type="email" />
            </Field>
          </div>
          <Field
            label="Jumlah Anggota"
            note={isMhq ? "Maks. 10 orang/tim" : "Solo: 1 orang | Grup: sesuai kategori"}
          >
            <TextInput placeholder="Cth. 5" value={f("MEMBER_COUNT")} onChange={set("MEMBER_COUNT")} />
          </Field>
        </div>
      </div>

      {/* Data Sekolah / Komunitas */}
      <div>
        <SectionTitle title="Asal Sekolah / Komunitas" />
        <div className="grid gap-4">
          <Field label="Nama Sekolah / Komunitas / Sanggar" required>
            <TextInput
              placeholder={isMhq ? "Cth. Sanggar Marawis Al-Hidayah / SMAN 2 Depok" : "Cth. SMAN 2 Depok / Sanggar Tari Nusantara"}
              value={f("NAMA_SEKOLAH")} onChange={set("NAMA_SEKOLAH")}
            />
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Jenjang / Kategori Peserta" required>
              <SelectInput
                placeholder="-- Pilih Jenjang --"
                value={f("GRADE")} onChange={set("GRADE")}
                options={
                  isMhq
                    ? ["SD (Sekolah Dasar)", "SMP (Sekolah Menengah Pertama)", "SMA/SMK (Sekolah Menengah Atas)", "Umum / Komunitas"]
                    : ["SD (Sekolah Dasar)", "SMP (Sekolah Menengah Pertama)", "SMA/SMK (Sekolah Menengah Atas)"]
                }
              />
            </Field>
            <Field label="Kota / Provinsi" required>
              <TextInput placeholder="Cth. Depok, Jawa Barat" value={f("PROVINCE")} onChange={set("PROVINCE")} />
            </Field>
          </div>
        </div>
      </div>

      {/* Data Pembimbing */}
      <div>
        <SectionTitle title="Guru Pembimbing / Penanggung Jawab" />
        <div className="grid gap-4">
          <Field label="Nama Pembimbing / PJ" required>
            <TextInput placeholder="Nama lengkap" value={f("NAME_SUPERVISOR")} onChange={set("NAME_SUPERVISOR")} />
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="WhatsApp Pembimbing" required>
              <TextInput placeholder="+62 …" value={f("WHATSAPP_NUMBER_SUPERVISOR")} onChange={set("WHATSAPP_NUMBER_SUPERVISOR")} type="tel" />
            </Field>
            <Field label="Email Pembimbing" required>
              <TextInput placeholder="pembimbing@email.com" value={f("EMAIL_TEACHER_SUPERVISOR")} onChange={set("EMAIL_TEACHER_SUPERVISOR")} type="email" />
            </Field>
          </div>
        </div>
      </div>

      {/* Detail Penampilan */}
      {f("CATEGORIES") && (
        <div>
          <SectionTitle title="Detail Penampilan" />
          <div className="grid gap-4">
            <Field
              label={isMhq ? "Judul Sholawat & Lagu Islami" : "Judul / Nama Penampilan"}
              required
              note={
                isMhq
                  ? "Tuliskan 1 judul sholawat dan 1 judul lagu bebas bernuansa islami. Cth: Sholawat: Ya Habibal Qolbi | Lagu: Tombo Ati"
                  : "Judul tari atau nama penampilan yang akan ditampilkan."
              }
            >
              <TextInput
                placeholder={isMhq ? "Sholawat: … | Lagu: …" : "Judul tari / penampilan"}
                value={f("PROJECT_TITLE")} onChange={set("PROJECT_TITLE")}
              />
            </Field>

            {/* Link file musik — khusus Tari */}
            {isTari && (
              <Field
                label="Link File Musik (Google Drive)"
                note="Upload file musik (MP3/WAV) ke Google Drive dan tempel link di sini. Wajib dikirim H-14 sebelum acara (sebelum 17 September 2026)."
              >
                <TextInput placeholder="https://drive.google.com/…" value={f("DRIVE_LINK")} onChange={set("DRIVE_LINK")} />
              </Field>
            )}

            {/* Daftar alat — khusus MHQ */}
            {isMhq && (
              <Field
                label="Peralatan Musik yang Dibawa"
                note="Peserta membawa peralatan sendiri. Peralatan elektronik TIDAK diperkenankan saat penampilan."
              >
                <TextArea
                  placeholder="Cth: Rebana (5 buah), Bedug (1 buah), Simbal (2 buah) …"
                  value={f("DRIVE_LINK")} onChange={set("DRIVE_LINK")} maxLength={300}
                />
              </Field>
            )}
          </div>
        </div>
      )}
    </>
  );
};

// ── Main Component ─────────────────────────────────────────────────
const DscfStepForm = ({ subEvent, onBack, onSuccess }: Props) => {
  const [form, setForm]           = useState<FormData>({});
  const [loading, setLoading]     = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError]         = useState("");

  const set = (key: string) => (v: string) => setForm(prev => ({ ...prev, [key]: v }));
  const f   = (key: string) => form[key] ?? "";

  const formWithMeta: FormData = {
    ...form,
    CATEGORY_COMPETITION: DSCF_SUB_LABELS[subEvent],
    CATEGORY_PRICE:       DSCF_PRICE_MAP[subEvent],
    ...(subEvent === "dmo" && !form["CATEGORIES"]
      ? { CATEGORIES: "Depok Math Olympiad (DMO)" }
      : {}),
  };

  const requiredFields = DSCF_REQUIRED_FIELDS[subEvent];
  const isValid = requiredFields.every(k => !!formWithMeta[k]?.trim());

  const handleSubmit = async () => {
    if (!isValid) return;
    setLoading(true);
    setError("");
    try {
      await submitToDscfSheet(subEvent, formWithMeta);
      setSubmitted(true);
    } catch {
      setError("Pengiriman gagal. Periksa koneksi Anda dan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  const subLabel = DSCF_SUB_LABELS[subEvent];

  return (
    <div className="w-full">

      {/* Header */}
      <div className="text-center mb-8">
        <p className="text-sm uppercase tracking-[0.3em] text-primary mb-2 font-semibold">
          Langkah 3 dari 3
        </p>
        <h2 className="text-2xl md:text-3xl font-bold font-display">Formulir Pendaftaran</h2>
        <p className="text-muted-foreground mt-1 text-sm">DSCF 2026 · {subLabel} · Depok, Indonesia</p>
      </div>

      <div className="tech-shell rounded-2xl p-6 md:p-8 space-y-8">

        {/* Info banner */}
        <div className="rounded-xl p-4 text-sm text-muted-foreground leading-6 bg-primary/5 border border-primary/20">
          <p className="font-semibold text-foreground mb-2">📌 DSCF 2026 — {subLabel}</p>
          <ol className="list-decimal list-inside space-y-1">
            <li>Isi semua data dengan benar. Data yang dikirim bersifat <strong className="text-foreground">final</strong> dan tidak dapat diubah.</li>
            <li>Selesaikan pembayaran paling lambat <strong className="text-foreground">27 Agustus 2026</strong>.</li>
            <li>Berita transfer: <strong className="text-foreground">IESF + Nama Lengkap</strong>.</li>
            <li>LoA dikirim ke email ketua dalam <strong className="text-foreground">3 hari kerja</strong> setelah pembayaran terverifikasi.</li>
            <li>Biaya pendaftaran: <strong className="text-primary">{DSCF_PRICE_MAP[subEvent]}</strong></li>
          </ol>
        </div>

        {/* Form per sub-event */}
        {subEvent === "desf" && <DesfForm f={f} set={set} />}
        {subEvent === "dmo"  && <DmoForm  f={f} set={set} />}
        {subEvent === "dcc"  && <DccForm  f={f} set={set} />}

        {/* Informasi Umum */}
        <div>
          <SectionTitle title="Informasi Umum" />
          <div className="grid gap-4">
            <Field label="Alamat Lengkap" required note="Jalan, Kelurahan, Kecamatan, Kota, Provinsi">
              <TextArea
                placeholder="Masukkan alamat lengkap…"
                value={f("COMPLETE_ADDRESS")} onChange={set("COMPLETE_ADDRESS")}
              />
            </Field>
            <Field label="Dari mana Anda mengetahui DSCF 2026?">
              <SelectInput
                placeholder="-- Pilih Sumber Informasi --"
                value={f("INFORMATION_RESOURCES")} onChange={set("INFORMATION_RESOURCES")}
                options={["Instagram", "WhatsApp", "Teman / Guru", "Website ICGI", "YouTube", "Lainnya"]}
              />
            </Field>
          </div>
        </div>

        {/* Bukti Pembayaran */}
        <div>
          <SectionTitle title="Bukti Pembayaran" />
          <div className="grid gap-4">
            <div className="rounded-xl p-4 text-xs text-muted-foreground bg-muted/30 border border-border/50 leading-6">
              <p className="font-semibold text-foreground mb-1">💳 Informasi Rekening</p>
              <p>Bank Syariah Indonesia (BSI) · Kode: <strong className="text-foreground">451</strong></p>
              <p>No. Rekening: <strong className="text-foreground">352261658</strong></p>
              <p>Atas Nama: <strong className="text-foreground">YYS PUSAT INOVASI ANAK BERBAKAT IND</strong></p>
              <p className="mt-2 text-primary font-semibold">Berita Transfer: IESF + Nama Lengkap</p>
              <p className="mt-1">Batas akhir pembayaran: <strong className="text-foreground">27 Agustus 2026</strong></p>
            </div>
            <Field
              label="Link Bukti Pembayaran (Google Drive)"
              note="Upload foto / screenshot bukti transfer ke Google Drive dan tempel link-nya di sini."
            >
              <TextInput
                placeholder="https://drive.google.com/…"
                value={f("FILE")} onChange={set("FILE")}
              />
            </Field>
          </div>
        </div>

        {/* Error */}
        {error && (
          <p className="text-sm text-rose-400 bg-rose-400/10 border border-rose-400/20 rounded-lg px-4 py-3">
            {error}
          </p>
        )}

        {/* Submit */}
        <div className="pt-2 space-y-2">
          <Button
            className="w-full text-base py-4 font-bold tracking-widest uppercase"
            disabled={!isValid || loading}
            onClick={handleSubmit}
          >
            {loading ? "Mengirim…" : "Kirim Pendaftaran"}
          </Button>
          {!isValid && (
            <p className="text-xs text-center text-muted-foreground">
              Harap isi semua kolom wajib (*) sebelum mengirim
            </p>
          )}
        </div>
      </div>

      {/* Back */}
      <div className="mt-4">
        <Button variant="outline" size="sm" onClick={onBack}>
          ← Kembali
        </Button>
      </div>

      {loading && <SpinnerOverlay />}
      {submitted && <SuccessOverlay onDone={() => onSuccess(subEvent, formWithMeta)} />}
    </div>
  );
};

export default DscfStepForm;