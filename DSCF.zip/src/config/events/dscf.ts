// ================================================================
// dscf.ts
// Path: src/config/events/dscf.ts
//
// Data event DSCF (Depok Science & Cultural Festival) 2026
// Portal: NESF  |  Peserta: Indonesia Only
// Sub-kompetisi: DESF · DMO · DCC
// Semua teks: Bahasa Indonesia
// ================================================================

import type { EventDetailData } from "@/config/eventDetailTypes";

const dscf: EventDetailData = {
  slug: "dscf-2026",
  organizers: [
    { name: "ICGI", logo: "https://res.cloudinary.com/dwhobhexj/image/upload/v1778572483/Logo_ICGI_Bg_Transparant_1_rdvff1.png" },
  ],
  guidebookUrl: "", // Isi URL guidebook PDF jika sudah tersedia

  email:   "icgi.official.id@gmail.com",
  website: "www.icgi.or.id",
  venue:   "Depok, Indonesia",

  labels: {
    eventBadge:     "ICGI · DSCF 2026",
    heroBadge:      "Kompetisi · Nasional · Depok, Indonesia",
    categoriesDesc:
      "Peserta dapat mendaftar pada tiga sub-kompetisi: Depok Engineering Science Fair (DESF), Depok Math Olympiad (DMO), dan Depok Cultural Competition (DCC).",
    scheduleDesc:
      "DSCF 2026 berlangsung pada 29 September – 3 Oktober 2026 di Depok, mencakup Seremoni Pembukaan & DMO (29 Sep), DESF (30 Sep), DCC (1 Okt), dan Awarding (3 Okt).",
  },

  stats: [
    { value: "3",      label: "Sub-Kompetisi" },
    { value: "29 Sep", label: "Pembukaan" },
    { value: "24 Agt", label: "Batas Pendaftaran" },
    { value: "27 Agt", label: "Batas Pembayaran" },
  ],

  regSteps: [
    "Pilih sub-kompetisi yang ingin diikuti: DESF, DMO, atau DCC.",
    "Baca dan setujui Syarat & Ketentuan kompetisi.",
    "Isi Formulir Pendaftaran dengan data tim, sekolah, pembimbing, dan detail proyek/penampilan.",
    "Lakukan pembayaran dan unggah bukti transfer via Google Drive. Berita Transfer: IESF + Nama Lengkap.",
    "Surat Keputusan Penerimaan (LoA) akan dikirim ke email ketua tim dalam 3 hari kerja.",
  ],

  about: {
    welcome:
      "Depok Science & Cultural Festival (DSCF) 2026 hadir sebagai ajang kompetisi sekaligus apresiasi bagi pelajar untuk mengembangkan potensi di bidang sains, matematika, dan budaya. Kegiatan ini diharapkan dapat mendorong semangat inovasi, sportivitas, serta pelestarian budaya lokal di kalangan generasi muda.",
    background:
      "DSCF 2026 terdiri dari tiga sub-kompetisi: Depok Engineering Science Fair (DESF) dengan 8 kategori bidang sains dan rekayasa, Depok Math Olympiad (DMO) untuk kompetisi matematika individu, serta Depok Cultural Competition (DCC) yang mencakup lomba Tari dan MHQ (Marawis, Hadroh & Qasidah).",
    objectives: [
      "Meningkatkan minat dan bakat pelajar di bidang sains, matematika, dan budaya.",
      "Menjadi wadah kompetisi yang sehat, edukatif, dan mendorong kreativitas serta inovasi generasi muda.",
      "Melestarikan budaya lokal melalui kompetisi seni dan membangun jaringan antar pelajar dari berbagai jenjang pendidikan.",
    ],
  },

  divisions: [
    { level: "Sekolah Dasar (SD)",            age: "Tingkat SD"    },
    { level: "Sekolah Menengah (SMP/SMA)",    age: "Tingkat SMP/SMA" },
    { level: "Umum (khusus MHQ)",             age: "Semua usia"    },
  ],

  // ── Kategori mencakup semua sub-kompetisi ──────────────────────
  categories: [
    // DESF
    {
      letter: "DESF-1",
      title:       "Matematika, Sains & Teknologi",
      description: "Berfokus pada pengembangan inovasi berbasis konsep matematika, sains, dan teknologi untuk memecahkan masalah secara efektif dan praktis.",
      icon: "Cpu",
    },
    {
      letter: "DESF-2",
      title:       "Lingkungan",
      description: "Mencakup proyek yang menawarkan solusi atas masalah lingkungan seperti perubahan iklim, pengelolaan sampah, konservasi, dan keberlanjutan.",
      icon: "Leaf",
    },
    {
      letter: "DESF-3",
      title:       "IoT & Robotika",
      description: "Menampilkan pengembangan perangkat berbasis IoT dan robotika yang bertujuan meningkatkan efisiensi dan otomatisasi di berbagai bidang.",
      icon: "Cpu",
    },
    {
      letter: "DESF-4",
      title:       "Informatika & Kecerdasan Buatan",
      description: "Berfokus pada pengembangan perangkat lunak, sistem informasi, dan penerapan kecerdasan buatan untuk memecahkan masalah secara inovatif.",
      icon: "Cpu",
    },
    {
      letter: "DESF-5",
      title:       "Ilmu Hayati",
      description: "Mencakup penelitian biologi dan ilmu hayati, termasuk kesehatan, genetika, mikrobiologi, dan bioteknologi.",
      icon: "HeartPulse",
    },
    {
      letter: "DESF-6",
      title:       "Ilmu Sosial & Humaniora",
      description: "Menganalisis fenomena sosial, budaya, dan humaniora untuk memberikan solusi atas masalah sosial melalui pendekatan ilmiah.",
      icon: "Users",
    },
    {
      letter: "DESF-7",
      title:       "Fisika, Energi & Teknik",
      description: "Berfokus pada penerapan konsep fisika, energi, dan teknik untuk menciptakan inovasi teknologi yang efisien dan berkelanjutan.",
      icon: "FlaskConical",
    },
    {
      letter: "DESF-8",
      title:       "Kesehatan & Kedokteran",
      description: "Mencakup inovasi dan penelitian di bidang kesehatan dan kedokteran yang bertujuan meningkatkan kualitas hidup dan layanan kesehatan.",
      icon: "HeartPulse",
    },
    // DMO
    {
      letter: "DMO",
      title:       "Depok Math Olympiad",
      description: "Kompetisi matematika individu satu babak. Peserta mengerjakan soal pilihan ganda sesuai jenjang. Penilaian berdasarkan ketepatan dan jumlah jawaban benar.",
      icon: "FlaskConical",
    },
    // DCC
    {
      letter: "DCC-1",
      title:       "Tari",
      description: "Menampilkan kreativitas, kekompakan, dan keindahan gerakan tari sebagai bentuk pelestarian seni dan budaya. Durasi dan kategori (solo/grup) sesuai ketentuan panitia.",
      icon: "Users",
    },
    {
      letter: "DCC-2",
      title:       "MHQ (Marawis, Hadroh & Qasidah)",
      description: "Menampilkan seni musik islami melalui harmonisasi vokal dan tabuhan rebana. Maksimal 10 orang/tim, membawakan 1 sholawat dan 1 lagu bebas bernuansa islami. Waktu maksimal 7 menit.",
      icon: "Users",
    },
  ],

  // ── Kriteria penilaian gabungan (DESF sebagai utama) ──────────
  judgingCriteria: [
    // DESF
    { aspect: "Inovasi & Orisinalitas (DESF)",   weight: "30%" },
    { aspect: "Metodologi (DESF)",               weight: "25%" },
    { aspect: "Dampak / Efek (DESF)",            weight: "20%" },
    { aspect: "Presentasi (DESF)",               weight: "15%" },
    { aspect: "Booth & Standing Banner (DESF)",  weight: "10%" },
    // DCC Tari
    { aspect: "Teknik Gerak (Tari)",             weight: "30%" },
    { aspect: "Ekspresi & Penjiwaan (Tari)",     weight: "20%" },
    { aspect: "Kreativitas Koreografi (Tari)",   weight: "20%" },
    { aspect: "Kostum & Penampilan (Tari)",      weight: "20%" },
    { aspect: "Kekompakan (Tari)",               weight: "10%" },
    // DCC MHQ
    { aspect: "Kekompakan Tim (MHQ)",            weight: "30%" },
    { aspect: "Vokal & Harmonisasi (MHQ)",       weight: "30%" },
    { aspect: "Aransemen Musik (MHQ)",           weight: "20%" },
    { aspect: "Penampilan Panggung (MHQ)",       weight: "20%" },
  ],

  awards: [
    // DESF
    { place: "DESF — Juara Pertama",              medal: "Sertifikat & Medali", extra: "ICGI Platinum / Achievement Award (selektif)" },
    { place: "DESF — Juara Kedua",                medal: "Sertifikat & Medali", extra: "" },
    { place: "DESF — Juara Ketiga",               medal: "Sertifikat & Medali", extra: "" },
    { place: "DESF — Juara Keempat",              medal: "Sertifikat & Medali", extra: "" },
    // DMO
    { place: "DMO — Penghargaan Emas",            medal: "Sertifikat & Medali", extra: "KKM > 80"  },
    { place: "DMO — Penghargaan Perak",           medal: "Sertifikat & Medali", extra: "KKM 70–79" },
    { place: "DMO — Penghargaan Perunggu",        medal: "Sertifikat & Medali", extra: "KKM < 69"  },
    { place: "DMO — Penghargaan Terbaik",         medal: "Sertifikat & Medali", extra: "Nilai Kelulusan tertinggi" },
    // DCC Tari
    { place: "DCC Tari — Juara Pertama",          medal: "Hadiah & Sertifikat", extra: "" },
    { place: "DCC Tari — Juara Kedua",            medal: "Hadiah & Sertifikat", extra: "" },
    { place: "DCC Tari — Juara Ketiga",           medal: "Hadiah & Sertifikat", extra: "" },
    { place: "DCC Tari — Kostum Terbaik",         medal: "Hadiah & Sertifikat", extra: "" },
    // DCC MHQ
    { place: "DCC MHQ — 5–6 Tim Terpilih",       medal: "Hadiah & Sertifikat", extra: "Sistem parade/undian" },
  ],

  scheduleOffline: [
    {
      day: 1, date: "29 September 2026", title: "Seremoni Pembukaan & DMO",
      items: [
        { time: "10.00 – 11.00", description: "Seremoni Pembukaan DSCF 2026", location: "Depok" },
        { time: "12.30 – Selesai", description: "Depok Math Olympiad (DMO)", location: "Depok" },
      ],
    },
    {
      day: 2, date: "30 September 2026", title: "Depok Engineering Science Fair (DESF)",
      items: [
        { time: "07.00 – 09.00", description: "Set up Booth Peserta", location: "Depok" },
        { time: "09.00 – 10.00", description: "Briefing Juri", location: "Depok" },
        { time: "10.00 – 16.00", description: "Penilaian DESF", location: "Depok" },
      ],
    },
    {
      day: 3, date: "1 Oktober 2026", title: "Depok Cultural Competition (DCC)",
      items: [
        { time: "09.00 – 12.00", description: "Lomba Tari (Solo & Grup)", location: "Depok" },
        { time: "13.00 – Selesai", description: "MHQ (Marawis, Hadroh & Qasidah)", location: "Depok" },
      ],
    },
    {
      day: 4, date: "2 Oktober 2026", title: "Free Time",
      items: [
        { time: "Seharian", description: "Free Time", location: "Depok" },
      ],
    },
    {
      day: 5, date: "3 Oktober 2026", title: "Awarding DSCF 2026",
      items: [
        { time: "09.30 – Selesai", description: "Upacara Penghargaan & Penutupan DSCF 2026", location: "Depok" },
      ],
    },
  ],

  scheduleOnline: [], // DSCF hanya offline

  schedule: [], // kept for type compatibility
};

export default dscf;